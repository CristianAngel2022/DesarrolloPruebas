const express = require('express');
const session = require ('express-session');
const handlebars = require('express-handlebars');
const fs = require('fs');
const axios = require('axios');

const app = express();
const PORT = 3000;

//Middlewares

app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'test',
    resave: false,
    saveUninitialized: false,
}));
app.set('views', __dirname);
app.engine('hbs', handlebars({
    defaultLayout: 'main',
    layoutsDir: __dirname,
    extname: '.hbs',
}));
app.set('view engine', 'hbs');

//Routes

app.get('/home', (req, res) => {
    res.send('Home');
});

app.get('/index', (req, res) => {
    res.render('index');
});

app.post('/index', (req, res) => {


    
    if(!req.body.id){
        axios.get('http://localhost:8080/thService/employees/findAll')
        .then(function(response) {

            console.log(response.data);
            res.render('employeeInfo',{data:response.data.response});

        })
        .catch(function (error){
            console.log(error);
        });
    }else{
        axios.get('http://localhost:8080/thService/employees/findById/'+req.body.id)
        .then(function(response) {

            console.log(response.data.response);
            res.render('employeeInfo',{data:response.data});

        })
        .catch(function (error){
            console.log(error);
        });
    }

});

app.listen(PORT, () => console.log('Listening on port', PORT));