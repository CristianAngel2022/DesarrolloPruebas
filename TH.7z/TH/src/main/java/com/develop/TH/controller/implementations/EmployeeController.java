package com.develop.TH.controller.implementations;

import com.develop.TH.controller.interfaces.IEmployeeController;
import com.develop.TH.dto.GeneralResponseDto;
import com.develop.TH.dto.EmployeeResponseDto;
import com.develop.TH.services.interfaces.IEmployeeService;
import com.develop.TH.tools.Tools;
import com.develop.TH.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("thService/")
@RestController
public class EmployeeController implements IEmployeeController {

    @Autowired
    private IEmployeeService service;

    @Override
    public ResponseEntity<GeneralResponseDto<List<EmployeeResponseDto>>> findAll() {
        return Tools.responseOk(service.findAll());
    }

    @Override
    public ResponseEntity<GeneralResponseDto<EmployeeResponseDto>> findEmployeeById(int idEmployee) {
        return Tools.responseOk(service.findEmployeeById(idEmployee));
    }

}
