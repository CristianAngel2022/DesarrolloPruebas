
package com.develop.TH.controller.interfaces;

import com.develop.TH.dto.GeneralResponseDto;
import com.develop.TH.dto.EmployeeResponseDto;
import com.develop.TH.utils.Constants;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

public interface IEmployeeController {

    @GetMapping(Constants.ServiceName.EMPLOYEES_FIND_ALL)
    ResponseEntity<GeneralResponseDto<List<EmployeeResponseDto>>> findAll();

    @GetMapping(Constants.ServiceName.EMPLOYEES_FIND_BY_ID + "/{idEmployee}")
    ResponseEntity<GeneralResponseDto<EmployeeResponseDto>> findEmployeeById(@PathVariable int idEmployee);

}
