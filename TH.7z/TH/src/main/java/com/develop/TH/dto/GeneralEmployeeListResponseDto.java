package com.develop.TH.dto;

import java.util.List;

public class GeneralEmployeeListResponseDto extends GeneralResponse{

    private List<EmployeeResponseDto> data;

    public List<EmployeeResponseDto> getData() {
        return data;
    }

    public void setData(List<EmployeeResponseDto> data) {
        this.data = data;
    }

}
