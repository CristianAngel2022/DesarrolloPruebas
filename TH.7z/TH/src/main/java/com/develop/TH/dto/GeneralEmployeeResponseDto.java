package com.develop.TH.dto;

import java.util.List;

public class GeneralEmployeeResponseDto extends GeneralResponse{

    private EmployeeResponseDto data;

    public EmployeeResponseDto getData() {
        return data;
    }

    public void setData(EmployeeResponseDto data) {
        this.data = data;
    }
}
