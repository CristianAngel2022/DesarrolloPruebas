
package com.develop.TH.dto;

/**
 * The Class GeneralResponseDTO.
 *
 * @param <T>
 *        the generic type
 */
public class GeneralResponseDto<T> {

    /** The Constant SERVICE_NAME_ATTRIBUTE. */
    public static final String SERVICE_NAME_ATTRIBUTE = "serviceName";

    /** The service name. */
    private String serviceName;

    /** The status code. */
    private Integer statusCode;

    /** The message. */
    private String message;

    /** The response. */
    private T response;

    /**
     * Gets the service name.
     *
     * @return the service name
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Sets the service name.
     *
     * @param serviceName
     *        the new service name
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    public Integer getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the status code.
     *
     * @param statusCode
     *        the new status code
     */
    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Gets the message.
     *
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the message.
     *
     * @param message
     *        the new message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Gets the response.
     *
     * @return the response
     */
    public T getResponse() {
        return response;
    }

    /**
     * Sets the response.
     *
     * @param response
     *        the new response
     */
    public void setResponse(T response) {
        this.response = response;
    }

}
