package com.develop.TH.exceptions;

public enum ReasonResponse {

    INTERNAL_ERROR(-1),
    SUCCESS(0);

    private Integer code;

    private ReasonResponse(Integer code) {
        this.code = code;
    }
    public Integer getCode() {
        return code;
    }


}
