package com.develop.TH.services.implementations;

import com.develop.TH.dto.EmployeeResponseDto;
import com.develop.TH.dto.GeneralEmployeeListResponseDto;
import com.develop.TH.dto.GeneralEmployeeResponseDto;
import com.develop.TH.services.interfaces.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class EmployeeService implements IEmployeeService {

    @Autowired
    private RestTemplate restTemplateApigee;

    @Override
    public List<EmployeeResponseDto> findAll() {

        ResponseEntity<GeneralEmployeeListResponseDto> res = restTemplateApigee.exchange("http://dummy.restapiexample.com/api/v1/employees", HttpMethod.GET, null, GeneralEmployeeListResponseDto.class);

        return res.getBody().getData();
    }

    @Override
    public EmployeeResponseDto findEmployeeById(int idEmployee) {

        System.out.println("http://dummy.restapiexample.com/api/v1/employee/"+idEmployee);
        ResponseEntity<GeneralEmployeeResponseDto> res = restTemplateApigee.exchange("http://dummy.restapiexample.com/api/v1/employee/"+idEmployee, HttpMethod.GET, null, GeneralEmployeeResponseDto.class);

        return res.getBody().getData();
    }
}
