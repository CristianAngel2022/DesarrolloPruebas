package com.develop.TH.services.interfaces;

import com.develop.TH.dto.EmployeeResponseDto;

import java.util.List;

public interface IEmployeeService {

    List<EmployeeResponseDto> findAll();
    EmployeeResponseDto findEmployeeById(int idEmployee);
}
