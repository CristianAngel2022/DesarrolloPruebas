package com.develop.TH.tools;

import com.develop.TH.dto.GeneralResponseDto;
import com.develop.TH.exceptions.ReasonResponse;
import org.springframework.http.ResponseEntity;

public class Tools {

    public static <T> ResponseEntity<GeneralResponseDto<T>> responseOk(T response) {
        return responseOk(response, ReasonResponse.SUCCESS);
    }

    public static <T> ResponseEntity<GeneralResponseDto<T>> responseOk(T response, ReasonResponse reason) {

        GeneralResponseDto<T> generalResponse = new GeneralResponseDto();
        generalResponse.setMessage(String.valueOf(ReasonResponse.SUCCESS));
        generalResponse.setResponse(response);
        generalResponse.setServiceName("employee");
        generalResponse.setStatusCode(ReasonResponse.SUCCESS.getCode());
        return ResponseEntity.ok(generalResponse);
    }
}
