package com.develop.TH.utils;

public class Constants {

    public static class ServiceName {

        public static final String FIND_ALL = "findAll";
        public static final String FIND_BY_ID = "findById";
        public static final String EMPLOYEES = "employees/";


        public static final String EMPLOYEES_FIND_ALL = EMPLOYEES + FIND_ALL;
        public static final String EMPLOYEES_FIND_BY_ID = EMPLOYEES + FIND_BY_ID;
    }
}
